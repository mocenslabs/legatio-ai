# CI fix: constitution auto v1

`create_constitution` seeds version 1. `create_constitution_with_rules` reuses that v1.
Tests updated accordingly.

```bash
cd ~/projects/legatio-ai-v2
unzip ci_constitution_version_fix.zip -d /tmp/cif
PKG=/tmp/cif/ci_constitution_version_fix

cp "$PKG/backend/apps/constitutions/services.py" backend/apps/constitutions/
cp "$PKG/backend/tests/unit/constitutions/test_services.py" backend/tests/unit/constitutions/
cp "$PKG/backend/tests/integration/constitutions/test_api.py" backend/tests/integration/constitutions/

docker compose -f infrastructure/docker-compose.yml --env-file .env exec backend \
  pytest tests/unit/constitutions/test_services.py tests/integration/constitutions/test_api.py -v --tb=short
```
